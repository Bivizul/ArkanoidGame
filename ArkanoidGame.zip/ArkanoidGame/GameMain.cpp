﻿#include "Application.h"
#include <SFML/Graphics.hpp>

using namespace ArkanoidGame;

int main()
{
	Application::Instance().Run();

	return 0;
}
